
from setuptools import setup

setup(name = "MainCode", version = "0.1.0", packages = ["MainCode"])
setup_keywords = ('distclass', 'script_name', 'script_args', 'options', 'name', 'version', 'author', 
'author_email', 'maintainer', 'maintainer_email','url','license','description', 'long_description', 
'keywords', 'platforms', 'classifiers', 'download_url', 'requires','provides','obsoletes')
