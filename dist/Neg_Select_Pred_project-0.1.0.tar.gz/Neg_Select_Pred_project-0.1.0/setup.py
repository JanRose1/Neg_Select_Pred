
from setuptools import setup

setup(name = "Neg_Select_Pred_project", version = "0.1.0", packages = ["Neg_Sel_Pred"])
